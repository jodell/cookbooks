
# Resuse from opscode
# include_recipe 'java'

include_recipe 'ruby'
