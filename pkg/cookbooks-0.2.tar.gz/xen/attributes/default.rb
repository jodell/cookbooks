

set_unless[:xen][:modules][:max_loop] = '64'
