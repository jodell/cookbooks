maintainer "Jeffrey ODell"
maintainer_email "jeffrey.odell@gmail.com"
description "<desc>"
version "0.1"

%w{ debian ubuntu }.each do |os|
  supports os
end
