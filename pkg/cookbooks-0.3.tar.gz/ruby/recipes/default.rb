%w(
ruby
ruby-dev
rake
rubygems
).each { |p| package p }
