%w(
xvfb
xfonts-100dpi
xfonts-75dpi
xfonts-scalable
xfonts-cyrillic
).each { |p| package p }
