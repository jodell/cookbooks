%w(
default-jre-headless
firefox
imagemagick
).each { |p| package p }
